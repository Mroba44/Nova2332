<?php
/**
 * index.php — Homepage.
 */
declare(strict_types=1);
require_once __DIR__ . '/config.php';

$pageTitle = APP_NAME . ' — Standard SA-MP Roleplay Server';
$activeNav = 'home';
$status    = SampQuery::getStatus();

$db = Database::getInstance();
$latestNews = [];
try {
    $latestNews = $db->fetchAll(
        'SELECT title, excerpt, category, published_at FROM news
         WHERE status = "published" ORDER BY published_at DESC LIMIT 3'
    );
} catch (\Throwable $e) {
    // news table may not be seeded yet on a fresh install — fail soft.
}

require __DIR__ . '/includes/header.php';
?>

<section class="hero container">
  <div class="hero-copy">
    <span class="hero-kicker"><span class="dot"></span> Persistent world, live right now</span>
    <h1>A city that keeps<br>running <span>without you</span>.</h1>
    <p class="hero-sub">Nova Global RP is a standard SA-MP roleplay server: a custom economy, player-run businesses and factions, and admins who actually enforce the rulebook. Pick a life, not a spawn point.</p>
    <div class="hero-actions">
      <a href="<?= url('/register.php') ?>" class="btn btn-primary btn-lg"><i class="fa-solid fa-play"></i> Create your character</a>
      <a href="<?= url('/download.php') ?>" class="btn btn-outline btn-lg"><i class="fa-solid fa-download"></i> Download launcher</a>
    </div>
    <div class="hero-meta">
      <div><strong id="statPlayers"><?= (int) ($status['players'] ?? 0) ?></strong><span>Online now</span></div>
      <div><strong>24/7</strong><span>Uptime target</span></div>
      <div><strong>0.3.7</strong><span>SA-MP version</span></div>
    </div>
  </div>

  <div class="hud-panel" id="serverHud">
    <div class="hud-title">
      <h3>Live server status</h3>
      <span class="status-pill <?= !empty($status['online']) ? 'online' : 'offline' ?>" data-hud="pill">
        <span class="dot"></span> <?= !empty($status['online']) ? 'Online' : 'Offline' ?>
      </span>
    </div>
    <div class="hud-server-name" data-hud="hostname"><?= e($status['hostname'] ?? APP_NAME . ' | Standard SA-MP') ?></div>

    <div class="player-bar-track">
      <?php $pct = !empty($status['max_players']) ? min(100, ((int)($status['players'] ?? 0) / (int)$status['max_players']) * 100) : 0; ?>
      <div class="player-bar-fill" data-hud="barfill" style="width: <?= $pct ?>%;"></div>
    </div>

    <div class="hud-grid">
      <div class="hud-stat">
        <strong><span data-hud="players"><?= (int) ($status['players'] ?? 0) ?></span> <span data-hud="maxplayers" style="font-size:14px;color:var(--muted-dim);">/ <?= (int) ($status['max_players'] ?? 0) ?></span></strong>
        <span>Players</span>
      </div>
      <div class="hud-stat">
        <strong data-hud="ping"><?= (int) ($status['ping'] ?? 0) ?> ms</strong>
        <span>Latency</span>
      </div>
      <div class="hud-stat">
        <strong><?= e($status['gamemode'] ?? 'Nova RP') ?></strong>
        <span>Gamemode</span>
      </div>
      <div class="hud-stat">
        <strong><?= !empty($status['password']) ? 'Yes' : 'No' ?></strong>
        <span>Whitelisted</span>
      </div>
    </div>

    <div style="font-size:12px;color:var(--muted-dim);display:flex;justify-content:space-between;align-items:center;">
      <span><?= e(SAMP_SERVER_IP) ?>:<?= SAMP_SERVER_PORT ?></span>
      <a href="<?= url('/server.php') ?>">Full status <i class="fa-solid fa-arrow-right" style="font-size:10px;"></i></a>
    </div>
  </div>
</section>

<hr class="divider">

<section class="section container" id="features">
  <div class="section-head">
    <h2>Built for people who want a second life, not a lobby.</h2>
    <p>Every system below runs on our own Pawn gamemode and MySQL backend — not a rented template.</p>
  </div>
  <div class="dossier-grid">
    <div class="dossier-tile" data-aos="fade-up">
      <div class="icon"><i class="fa-solid fa-sack-dollar"></i></div>
      <h3>Player-driven economy</h3>
      <p>Prices react to supply and demand across businesses, not fixed admin-set numbers.</p>
    </div>
    <div class="dossier-tile" data-aos="fade-up" data-aos-delay="60">
      <div class="icon"><i class="fa-solid fa-house-chimney"></i></div>
      <h3>Houses & businesses</h3>
      <p>Buy, furnish, and run property as a landlord, shop owner, or silent investor.</p>
    </div>
    <div class="dossier-tile" data-aos="fade-up" data-aos-delay="120">
      <div class="icon"><i class="fa-solid fa-users-rectangle"></i></div>
      <h3>Families & factions</h3>
      <p>Structured hierarchies with ranks, turf, and consequences that persist between sessions.</p>
    </div>
    <div class="dossier-tile" data-aos="fade-up">
      <div class="icon"><i class="fa-solid fa-car-side"></i></div>
      <h3>Full vehicle system</h3>
      <p>Ownership, insurance, impound, and a dealership market with fluctuating stock.</p>
    </div>
    <div class="dossier-tile" data-aos="fade-up" data-aos-delay="60">
      <div class="icon"><i class="fa-solid fa-shield-halved"></i></div>
      <h3>Active moderation</h3>
      <p>A staff team with logged actions, a ticket system, and an in-game report queue.</p>
    </div>
    <div class="dossier-tile" data-aos="fade-up" data-aos-delay="120">
      <div class="icon"><i class="fa-solid fa-chart-line"></i></div>
      <h3>Public leaderboards</h3>
      <p>Wealth, playtime, and faction standing — tracked and visible on the website.</p>
    </div>
  </div>
</section>

<hr class="divider">

<section class="section container" id="news">
  <div class="section-head" style="display:flex;justify-content:space-between;align-items:flex-end;width:100%;max-width:none;">
    <div>
      <h2>Latest from the city desk</h2>
      <p>Patch notes, event announcements, and staff updates.</p>
    </div>
  </div>

  <?php if (!empty($latestNews)): ?>
    <?php foreach ($latestNews as $item): ?>
      <div class="news-row" data-aos="fade-up">
        <div class="news-date"><?= e(date('M d', strtotime((string) $item['published_at']))) ?></div>
        <div>
          <h4><?= e($item['title']) ?></h4>
          <p><?= e($item['excerpt']) ?></p>
        </div>
        <span class="news-tag"><?= e($item['category']) ?></span>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <div class="news-row">
      <div class="news-date"><?= date('M d') ?></div>
      <div>
        <h4>Nova Global RP is live</h4>
        <p>The server just launched — check back here for patch notes and event announcements.</p>
      </div>
      <span class="news-tag">Announcement</span>
    </div>
  <?php endif; ?>
</section>

<hr class="divider">

<section class="section container" style="text-align:center;">
  <h2 style="max-width:640px;margin:0 auto 16px;">Your character is waiting. You're just not logged in yet.</h2>
  <p style="margin:0 auto 32px;">Registration takes under a minute. No whitelist, no application form.</p>
  <a href="<?= url('/register.php') ?>" class="btn btn-primary btn-lg"><i class="fa-solid fa-play"></i> Create your character</a>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
