<?php
/**
 * forgot-password.php
 */
declare(strict_types=1);
require_once __DIR__ . '/config.php';

$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
$errors = [];
$sent   = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::requireCsrf();
    $email = (string) ($_POST['email'] ?? '');

    if (!Security::isValidEmail($email)) {
        $errors[] = 'Please enter a valid email address.';
    } elseif (!Security::rateLimit('forgot_' . Security::clientIp(), 5, 900)) {
        $errors[] = 'Too many requests. Please wait a while before trying again.';
    } else {
        Auth::requestPasswordReset($email);
        $sent = true;
        $msg  = 'If that email is registered, a reset link is on its way.';
        if ($isAjax) {
            jsonResponse(['success' => true, 'title' => 'Check your inbox', 'message' => $msg]);
        }
    }

    if ($isAjax && !empty($errors)) {
        jsonResponse(['success' => false, 'errors' => $errors], 422);
    }
}

$pageTitle = 'Forgot Password — ' . APP_NAME;
$extraHead = '<link rel="stylesheet" href="' . url('assets/css/auth.css') . '">';
require __DIR__ . '/includes/header.php';
?>

<div class="auth-shell">
  <div class="auth-visual">
    <div class="quote">
      <p>"Lost your password, not your progress."</p>
      <span>— Nova Global RP, Account Recovery</span>
    </div>
  </div>

  <div class="auth-form-wrap">
    <div class="auth-card">
      <h1>Reset your password</h1>
      <p class="lead">Enter the email on your account and we'll send a reset link.</p>

      <?php if ($sent): ?>
        <div class="flash success" style="margin-bottom:20px;position:static;">
          If that email is registered, a reset link is on its way. It expires in 1 hour.
        </div>
      <?php endif; ?>

      <?php if (!empty($errors)): ?>
        <div class="form-error">
          <ul><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <form method="post" action="<?= url('/forgot-password.php') ?>" data-ajax novalidate>
        <?= Security::csrfField() ?>
        <div class="field">
          <label for="email">Email address</label>
          <input type="email" id="email" name="email" autocomplete="email" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block btn-lg">Send reset link</button>
      </form>

      <p class="auth-switch"><a href="<?= url('/login.php') ?>">Back to log in</a></p>
    </div>
  </div>
</div>

<?php
$extraScripts = '<script src="' . url('assets/js/auth.js') . '"></script>';
require __DIR__ . '/includes/footer.php';
?>
