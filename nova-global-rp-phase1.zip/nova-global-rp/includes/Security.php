<?php
/**
 * Security.php
 *
 * CSRF token issuance/verification, output escaping helpers,
 * input sanitization, rate limiting, and a minimal brute-force
 * throttle backed by the `login_attempts` table.
 *
 * @package NovaGlobalRP
 */

declare(strict_types=1);

final class Security
{
    /** Generate (or reuse) the CSRF token for the current session. */
    public static function csrfToken(): string
    {
        if (empty($_SESSION[CSRF_TOKEN_NAME])) {
            $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
        }
        return $_SESSION[CSRF_TOKEN_NAME];
    }

    /** Render a hidden <input> carrying the current CSRF token. */
    public static function csrfField(): string
    {
        return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' .
            self::e(self::csrfToken()) . '">';
    }

    /** Verify a submitted token using a timing-safe comparison. */
    public static function verifyCsrf(?string $submitted): bool
    {
        if (!is_string($submitted) || empty($_SESSION[CSRF_TOKEN_NAME])) {
            return false;
        }
        return hash_equals($_SESSION[CSRF_TOKEN_NAME], $submitted);
    }

    /** Abort the request with a 419 if the CSRF token is missing/invalid. */
    public static function requireCsrf(): void
    {
        $token = $_POST[CSRF_TOKEN_NAME] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
        if (!self::verifyCsrf($token)) {
            http_response_code(419);
            error_log('[SECURITY] CSRF validation failed for ' . ($_SERVER['REQUEST_URI'] ?? 'unknown'));
            exit('Your session has expired. Please refresh the page and try again.');
        }
    }

    /** HTML-escape for safe output (XSS defense at the render boundary). */
    public static function e(?string $value): string
    {
        return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    /** Strip tags and trim whitespace from a raw input string. */
    public static function clean(?string $value): string
    {
        return trim(strip_tags($value ?? ''));
    }

    public static function isValidEmail(string $email): bool
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    /**
     * Enforce a password policy: 8+ chars, upper, lower, digit.
     * Returns an array of violation messages (empty = passes).
     */
    public static function passwordViolations(string $password): array
    {
        $errors = [];
        if (strlen($password) < 8) {
            $errors[] = 'Password must be at least 8 characters long.';
        }
        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = 'Password must contain at least one uppercase letter.';
        }
        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = 'Password must contain at least one lowercase letter.';
        }
        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = 'Password must contain at least one number.';
        }
        return $errors;
    }

    public static function hashPassword(string $password): string
    {
        return password_hash($password . PASSWORD_PEPPER, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    public static function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password . PASSWORD_PEPPER, $hash);
    }

    public static function generateToken(int $bytes = 32): string
    {
        return bin2hex(random_bytes($bytes));
    }

    /** Best-effort real client IP behind a reverse proxy / Cloudflare. */
    public static function clientIp(): string
    {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = trim(explode(',', $_SERVER[$key])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }

    /**
     * Simple sliding-window rate limiter backed by the cache/ directory.
     * Returns true if the action is currently allowed.
     */
    public static function rateLimit(string $key, int $maxAttempts, int $windowSeconds): bool
    {
        $safeKey = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $key);
        $file    = __DIR__ . '/../cache/rl_' . $safeKey . '.json';
        $now     = time();

        $attempts = [];
        if (is_file($file)) {
            $data     = json_decode((string) file_get_contents($file), true);
            $attempts = is_array($data) ? $data : [];
        }
        $attempts = array_values(array_filter($attempts, fn($ts) => $ts > ($now - $windowSeconds)));

        if (count($attempts) >= $maxAttempts) {
            return false;
        }

        $attempts[] = $now;
        file_put_contents($file, json_encode($attempts), LOCK_EX);
        return true;
    }

    /** Record a login attempt for brute-force auditing. */
    public static function logLoginAttempt(string $identifier, bool $success): void
    {
        try {
            Database::getInstance()->execute(
                'INSERT INTO login_attempts (identifier, ip_address, success, user_agent, created_at)
                 VALUES (:identifier, :ip, :success, :ua, NOW())',
                [
                    'identifier' => $identifier,
                    'ip'         => self::clientIp(),
                    'success'    => $success ? 1 : 0,
                    'ua'         => substr($_SERVER['HTTP_USER_AGENT'] ?? 'unknown', 0, 255),
                ]
            );
        } catch (\Throwable $e) {
            error_log('[SECURITY] Failed to log login attempt: ' . $e->getMessage());
        }
    }

    /** Count recent failed attempts for an identifier+IP pair. */
    public static function recentFailedAttempts(string $identifier, int $minutes = 15): int
    {
        $row = Database::getInstance()->fetchOne(
            'SELECT COUNT(*) AS c FROM login_attempts
             WHERE identifier = :identifier AND ip_address = :ip AND success = 0
               AND created_at > (NOW() - INTERVAL :minutes MINUTE)',
            ['identifier' => $identifier, 'ip' => self::clientIp(), 'minutes' => $minutes]
        );
        return (int) ($row['c'] ?? 0);
    }
}
