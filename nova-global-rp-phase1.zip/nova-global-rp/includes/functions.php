<?php
/**
 * functions.php
 *
 * Small global helper functions used across the public site,
 * UCP, and admin panel. Kept intentionally framework-free.
 *
 * @package NovaGlobalRP
 */

declare(strict_types=1);

/** Escape shortcut mirroring Security::e() for use in templates. */
function e(?string $value): string
{
    return Security::e($value);
}

/** Build an absolute URL from a site-relative path. */
function url(string $path = ''): string
{
    return APP_URL . '/' . ltrim($path, '/');
}

/** Redirect and terminate the request. */
function redirect(string $path): never
{
    header('Location: ' . url($path));
    exit;
}

/** Flash a one-time message into the session (rendered by header.php). */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

/** Pop and return all pending flash messages. */
function getFlashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flashes;
}

/** Format a number with thousands separators, safely handling null. */
function formatNumber(int|float|null $value): string
{
    return number_format((float) ($value ?? 0));
}

/** Human-readable "time ago" string. */
function timeAgo(string $datetime): string
{
    $diff = time() - strtotime($datetime);
    if ($diff < 60) {
        return 'just now';
    }
    $units = [
        31536000 => 'year', 2592000 => 'month', 86400 => 'day',
        3600 => 'hour', 60 => 'minute',
    ];
    foreach ($units as $seconds => $label) {
        $count = intdiv($diff, $seconds);
        if ($count >= 1) {
            return $count . ' ' . $label . ($count > 1 ? 's' : '') . ' ago';
        }
    }
    return 'just now';
}

/** Current logged-in user's display name, or "Guest". */
function currentUsername(): string
{
    return $_SESSION['username'] ?? 'Guest';
}

/** Whether the current session user holds a staff role or higher. */
function isStaff(): bool
{
    return in_array($_SESSION['role'] ?? 'player', ['helper', 'moderator', 'administrator', 'developer', 'owner'], true);
}

/** Read a JSON request body as an associative array (used by API/AJAX endpoints). */
function jsonInput(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '[]', true);
    return is_array($data) ? $data : [];
}

/** Send a JSON response and terminate. */
function jsonResponse(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES);
    exit;
}
