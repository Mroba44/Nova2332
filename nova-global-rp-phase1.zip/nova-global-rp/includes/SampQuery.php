<?php
/**
 * SampQuery.php
 *
 * Minimal implementation of the SA-MP/open.mp UDP query protocol
 * (https://sampwiki.blast.hk/wiki/Query_Mechanism) used to pull
 * live server status: online/offline, player count, gamemode,
 * and the player list, directly from the game server — no
 * third-party API involved.
 *
 * Results are cached briefly to a flat file so a burst of page
 * loads doesn't hammer the game server with UDP queries.
 *
 * @package NovaGlobalRP
 */

declare(strict_types=1);

final class SampQuery
{
    private const CACHE_TTL = 15; // seconds

    /**
     * @return array{
     *   online: bool, hostname?: string, gamemode?: string, map?: string,
     *   players?: int, max_players?: int, password?: bool, ping?: int
     * }
     */
    public static function getStatus(): array
    {
        $cacheFile = __DIR__ . '/../cache/samp_status.json';

        if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < self::CACHE_TTL) {
            $cached = json_decode((string) file_get_contents($cacheFile), true);
            if (is_array($cached)) {
                return $cached;
            }
        }

        $result = self::queryLive();

        file_put_contents($cacheFile, json_encode($result), LOCK_EX);
        return $result;
    }

    private static function queryLive(): array
    {
        $ip   = SAMP_SERVER_IP;
        $port = SAMP_SERVER_PORT;

        $socket = @fsockopen('udp://' . $ip, $port, $errno, $errstr, SAMP_QUERY_TIMEOUT);
        if ($socket === false) {
            return ['online' => false];
        }
        stream_set_timeout($socket, SAMP_QUERY_TIMEOUT);

        try {
            $start = microtime(true);

            // --- 'i' packet: basic info (hostname, gamemode, map, players) ---
            $packet = self::buildPacket($ip, $port, 'i');
            fwrite($socket, $packet);
            $response = fread($socket, 2048);

            if ($response === false || strlen($response) < 11) {
                return ['online' => false];
            }

            $ping = (int) round((microtime(true) - $start) * 1000);

            $offset   = 11; // skip "SAMP" + ip(4) + port(2) + opcode(1) -> header is 4+4+2+1=11
            $password = unpack('C', substr($response, $offset, 1))[1];
            $offset += 1;
            $players = unpack('v', substr($response, $offset, 2))[1];
            $offset += 2;
            $maxPlayers = unpack('v', substr($response, $offset, 2))[1];
            $offset += 2;

            [$hostname, $offset] = self::readPascalString32($response, $offset);
            [$gamemode, $offset] = self::readPascalString32($response, $offset);
            [$map, $offset]      = self::readPascalString32($response, $offset);

            return [
                'online'      => true,
                'hostname'    => $hostname,
                'gamemode'    => $gamemode,
                'map'         => $map,
                'players'     => $players,
                'max_players' => $maxPlayers,
                'password'    => $password === 1,
                'ping'        => $ping,
            ];
        } catch (\Throwable $e) {
            error_log('[SAMPQUERY] ' . $e->getMessage());
            return ['online' => false];
        } finally {
            fclose($socket);
        }
    }

    /**
     * Returns the online player list via the 'd' (client list) packet.
     * @return array<int, array{name: string, score: int}>
     */
    public static function getPlayerList(): array
    {
        $ip   = SAMP_SERVER_IP;
        $port = SAMP_SERVER_PORT;

        $socket = @fsockopen('udp://' . $ip, $port, $errno, $errstr, SAMP_QUERY_TIMEOUT);
        if ($socket === false) {
            return [];
        }
        stream_set_timeout($socket, SAMP_QUERY_TIMEOUT);

        try {
            fwrite($socket, self::buildPacket($ip, $port, 'c'));
            $response = fread($socket, 4096);
            if ($response === false || strlen($response) < 12) {
                return [];
            }

            $offset = 11;
            $count  = unpack('v', substr($response, $offset, 2))[1];
            $offset += 2;

            $players = [];
            for ($i = 0; $i < $count; $i++) {
                if ($offset >= strlen($response)) {
                    break;
                }
                $nameLen = unpack('C', substr($response, $offset, 1))[1];
                $offset += 1;
                $name = substr($response, $offset, $nameLen);
                $offset += $nameLen;
                $score = unpack('l', substr($response, $offset, 4))[1];
                $offset += 4;
                $players[] = ['name' => $name, 'score' => $score];
            }
            return $players;
        } catch (\Throwable $e) {
            error_log('[SAMPQUERY] ' . $e->getMessage());
            return [];
        } finally {
            fclose($socket);
        }
    }

    private static function buildPacket(string $ip, int $port, string $opcode): string
    {
        $packet  = 'SAMP';
        $packet .= implode('', array_map(fn($o) => chr((int) $o), explode('.', $ip)));
        $packet .= chr($port & 0xFF) . chr(($port >> 8) & 0xFF);
        $packet .= $opcode;
        return $packet;
    }

    private static function readPascalString32(string $data, int $offset): array
    {
        $len = unpack('V', substr($data, $offset, 4))[1];
        $offset += 4;
        $str = substr($data, $offset, $len);
        $offset += $len;
        return [$str, $offset];
    }
}
