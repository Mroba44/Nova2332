<?php
/**
 * Mailer.php
 *
 * Thin wrapper around PHPMailer (installed via Composer — see
 * composer.json) for transactional email: verification links,
 * password resets, and notifications. Falls back to PHP's native
 * mail() only if PHPMailer isn't installed yet, so the app still
 * runs immediately after upload before `composer install` is run.
 *
 * @package NovaGlobalRP
 */

declare(strict_types=1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

final class Mailer
{
    private static function send(string $toEmail, string $toName, string $subject, string $html): bool
    {
        $vendorAutoload = __DIR__ . '/../vendor/autoload.php';

        if (is_file($vendorAutoload)) {
            require_once $vendorAutoload;
            try {
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host       = MAIL_HOST;
                $mail->SMTPAuth   = true;
                $mail->Username   = MAIL_USERNAME;
                $mail->Password   = MAIL_PASSWORD;
                $mail->SMTPSecure = MAIL_ENCRYPTION;
                $mail->Port       = MAIL_PORT;
                $mail->CharSet    = 'UTF-8';

                $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
                $mail->addAddress($toEmail, $toName);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body    = $html;
                $mail->AltBody = strip_tags($html);

                return $mail->send();
            } catch (PHPMailerException $e) {
                error_log('[MAILER] PHPMailer send failed: ' . $e->getMessage());
                return false;
            }
        }

        // Fallback: native mail() — functional but not recommended for production.
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM_ADDRESS . ">\r\n";
        return @mail($toEmail, $subject, $html, $headers);
    }

    public static function sendVerificationEmail(string $email, string $username, string $token): bool
    {
        $link = APP_URL . '/verify-email.php?token=' . urlencode($token);
        $html = self::layout(
            'Confirm your account',
            "Welcome to " . Security::e(APP_NAME) . ", <strong>" . Security::e($username) . "</strong>.",
            'Verify my email',
            $link,
            'This link expires in 24 hours. If you did not create this account, you can ignore this email.'
        );
        return self::send($email, $username, 'Verify your ' . APP_NAME . ' account', $html);
    }

    public static function sendPasswordResetEmail(string $email, string $username, string $token): bool
    {
        $link = APP_URL . '/reset-password.php?token=' . urlencode($token);
        $html = self::layout(
            'Reset your password',
            'We received a request to reset the password for <strong>' . Security::e($username) . '</strong>.',
            'Reset my password',
            $link,
            'This link expires in 1 hour. If you did not request this, you can safely ignore this email.'
        );
        return self::send($email, $username, 'Reset your ' . APP_NAME . ' password', $html);
    }

    private static function layout(string $heading, string $intro, string $buttonLabel, string $url, string $footnote): string
    {
        $appName = Security::e(APP_NAME);
        $heading = Security::e($heading);
        return <<<HTML
        <div style="font-family:Arial,sans-serif;background:#05070d;padding:32px;">
          <div style="max-width:480px;margin:0 auto;background:#0b1120;border:1px solid #1c2740;border-radius:12px;padding:32px;color:#f5f7fb;">
            <h1 style="color:#00e5ff;font-size:20px;margin:0 0 16px;">{$appName}</h1>
            <h2 style="font-size:18px;margin:0 0 12px;">{$heading}</h2>
            <p style="font-size:14px;line-height:1.6;color:#c4cbdb;">{$intro}</p>
            <p style="text-align:center;margin:28px 0;">
              <a href="{$url}" style="background:#2f6bff;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:8px;font-size:14px;display:inline-block;">{$buttonLabel}</a>
            </p>
            <p style="font-size:12px;color:#7c8496;">{$footnote}</p>
          </div>
        </div>
        HTML;
    }
}
