<?php
/**
 * header.php
 *
 * Shared <head>, navigation bar, and flash-message renderer.
 * Include after config.php. Expects an optional $pageTitle and
 * $activeNav (matches a data-nav value in the menu below).
 */

declare(strict_types=1);

$pageTitle = $pageTitle ?? APP_NAME;
$activeNav = $activeNav ?? '';
$user      = Auth::isLoggedIn() ? Auth::currentUser() : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?></title>
<meta name="description" content="Nova Global RP — a standard SA-MP roleplay server. Live economy, custom factions, and a persistent city.">
<link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 32 32%22><rect width=%2232%22 height=%2232%22 rx=%226%22 fill=%22%2305070d%22/><path d=%22M8 22V10l16 12V10%22 stroke=%22%2300e6ff%22 stroke-width=%222.4%22 fill=%22none%22 stroke-linecap=%22round%22 stroke-linejoin=%22round%22/></svg>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
<?= $extraHead ?? '' ?>
</head>
<body>

<div class="blueprint-bg" aria-hidden="true"></div>
<div class="horizon-glow" aria-hidden="true"></div>

<nav class="navbar">
  <div class="container">
    <a href="<?= url('/') ?>" class="brand">
      <svg class="mark" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="32" height="32" rx="6" fill="#0b1220"/>
        <path d="M8 22V10l16 12V10" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      Nova Global <span style="color:var(--blue)">RP</span>
    </a>

    <ul class="nav-links">
      <li><a href="<?= url('/') ?>" class="<?= $activeNav === 'home' ? 'active' : '' ?>">Home</a></li>
      <li><a href="<?= url('/#features') ?>">Features</a></li>
      <li><a href="<?= url('/#news') ?>">News</a></li>
      <?php if ($user): ?><li><a href="<?= url('/ucp/') ?>" class="<?= $activeNav === 'ucp' ? 'active' : '' ?>">My Account</a></li><?php endif; ?>
    </ul>

    <div class="nav-actions">
      <?php if ($user): ?>
        <a href="<?= url('/ucp/') ?>" class="btn btn-outline"><i class="fa-solid fa-user"></i> <?= e($user['username']) ?></a>
      <?php else: ?>
        <a href="<?= url('/login.php') ?>" class="btn btn-ghost">Log in</a>
        <a href="<?= url('/register.php') ?>" class="btn btn-primary">Play Now</a>
      <?php endif; ?>
      <button class="nav-toggle" id="navToggle" aria-label="Toggle menu" aria-expanded="false">
        <i class="fa-solid fa-bars"></i>
      </button>
    </div>
  </div>
</nav>

<div class="mobile-drawer" id="mobileDrawer">
  <ul>
    <li><a href="<?= url('/') ?>">Home</a></li>
    <li><a href="<?= url('/#features') ?>">Features</a></li>
    <li><a href="<?= url('/#news') ?>">News</a></li>
    <?php if ($user): ?><li><a href="<?= url('/ucp/') ?>">My Account</a></li><?php endif; ?>
  </ul>
  <?php if ($user): ?>
    <a href="<?= url('/ucp/') ?>" class="btn btn-outline btn-block">My Account</a>
  <?php else: ?>
    <a href="<?= url('/login.php') ?>" class="btn btn-ghost btn-block" style="margin-bottom:10px;">Log in</a>
    <a href="<?= url('/register.php') ?>" class="btn btn-primary btn-block">Play Now</a>
  <?php endif; ?>
</div>

<?php $flashes = getFlashes(); if (!empty($flashes)): ?>
<div class="flash-stack" id="flashStack">
  <?php foreach ($flashes as $f): ?>
    <div class="flash <?= e($f['type']) ?>"><?= e($f['message']) ?></div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
