<?php
/**
 * Auth.php
 *
 * Handles the full authentication lifecycle: registration, login,
 * logout, email verification tokens, and password reset tokens.
 * All queries are parameterized; all passwords are hashed with
 * bcrypt + a server-side pepper (see Security::hashPassword).
 *
 * @package NovaGlobalRP
 */

declare(strict_types=1);

final class Auth
{
    public static function isLoggedIn(): bool
    {
        return !empty($_SESSION['user_id']);
    }

    public static function requireLogin(string $redirectTo = '/login.php'): void
    {
        if (!self::isLoggedIn()) {
            header('Location: ' . APP_URL . $redirectTo);
            exit;
        }
    }

    public static function currentUser(): ?array
    {
        if (!self::isLoggedIn()) {
            return null;
        }
        return Database::getInstance()->fetchOne(
            'SELECT id, username, email, role, status, avatar, created_at
             FROM users WHERE id = :id LIMIT 1',
            ['id' => $_SESSION['user_id']]
        );
    }

    /**
     * Register a new account.
     *
     * @return array{success: bool, errors: string[], user_id?: string}
     */
    public static function register(string $username, string $email, string $password, string $confirm): array
    {
        $errors = [];

        $username = Security::clean($username);
        $email    = strtolower(trim($email));

        if (!preg_match('/^[A-Za-z0-9_\[\]\(\)]{3,24}$/', $username)) {
            $errors[] = 'Username must be 3-24 characters (letters, numbers, _ [ ] ( ) only) — SA-MP name format.';
        }
        if (!Security::isValidEmail($email)) {
            $errors[] = 'Please enter a valid email address.';
        }
        if ($password !== $confirm) {
            $errors[] = 'Password confirmation does not match.';
        }
        $errors = array_merge($errors, Security::passwordViolations($password));

        if (!empty($errors)) {
            return ['success' => false, 'errors' => $errors];
        }

        $db = Database::getInstance();

        $exists = $db->fetchOne(
            'SELECT id FROM users WHERE username = :u OR email = :e LIMIT 1',
            ['u' => $username, 'e' => $email]
        );
        if ($exists) {
            return ['success' => false, 'errors' => ['That username or email is already registered.']];
        }

        $verifyToken = Security::generateToken();

        try {
            $db->beginTransaction();

            $userId = $db->insert(
                'INSERT INTO users
                    (username, email, password_hash, role, status, email_verified, verify_token, created_at, updated_at)
                 VALUES
                    (:username, :email, :hash, :role, :status, 0, :token, NOW(), NOW())',
                [
                    'username' => $username,
                    'email'    => $email,
                    'hash'     => Security::hashPassword($password),
                    'role'     => 'player',
                    'status'   => 'active',
                    'token'    => $verifyToken,
                ]
            );

            $db->insert(
                'INSERT INTO user_wallets (user_id, cash, bank, coins, created_at)
                 VALUES (:uid, 0, 0, 0, NOW())',
                ['uid' => $userId]
            );

            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            error_log('[AUTH] Registration failed: ' . $e->getMessage());
            return ['success' => false, 'errors' => ['Registration failed. Please try again.']];
        }

        Mailer::sendVerificationEmail($email, $username, $verifyToken);
        AuditLog::record(null, 'account.register', "New account: {$username}");

        return ['success' => true, 'errors' => [], 'user_id' => $userId];
    }

    /**
     * Authenticate a user by username-or-email + password.
     *
     * @return array{success: bool, error?: string}
     */
    public static function login(string $identifier, string $password, bool $remember = false): array
    {
        $identifier = Security::clean($identifier);

        if (!Security::rateLimit('login_' . Security::clientIp(), 10, 300)) {
            return ['success' => false, 'error' => 'Too many login attempts. Please wait a few minutes.'];
        }

        if (Security::recentFailedAttempts($identifier) >= 5) {
            return ['success' => false, 'error' => 'Account temporarily locked due to repeated failed attempts. Try again later.'];
        }

        $db   = Database::getInstance();
        $user = $db->fetchOne(
            'SELECT id, username, email, password_hash, role, status, email_verified
             FROM users WHERE username = :i OR email = :i LIMIT 1',
            ['i' => $identifier]
        );

        if (!$user || !Security::verifyPassword($password, $user['password_hash'])) {
            Security::logLoginAttempt($identifier, false);
            return ['success' => false, 'error' => 'Incorrect username/email or password.'];
        }

        if ($user['status'] === 'banned') {
            Security::logLoginAttempt($identifier, false);
            return ['success' => false, 'error' => 'This account has been banned. Contact support if you believe this is an error.'];
        }

        if ((int) $user['email_verified'] !== 1) {
            Security::logLoginAttempt($identifier, false);
            return ['success' => false, 'error' => 'Please verify your email address before logging in.'];
        }

        Security::logLoginAttempt($identifier, true);

        session_regenerate_id(true);
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];

        $db->execute('UPDATE users SET last_login_at = NOW(), last_login_ip = :ip WHERE id = :id', [
            'ip' => Security::clientIp(),
            'id' => $user['id'],
        ]);

        $db->insert(
            'INSERT INTO login_history (user_id, ip_address, user_agent, created_at)
             VALUES (:uid, :ip, :ua, NOW())',
            [
                'uid' => $user['id'],
                'ip'  => Security::clientIp(),
                'ua'  => substr($_SERVER['HTTP_USER_AGENT'] ?? 'unknown', 0, 255),
            ]
        );

        if ($remember) {
            self::issueRememberToken((string) $user['id']);
        }

        AuditLog::record((string) $user['id'], 'account.login', 'Successful login');

        return ['success' => true];
    }

    public static function logout(): void
    {
        $uid = $_SESSION['user_id'] ?? null;
        if ($uid) {
            AuditLog::record((string) $uid, 'account.logout', 'User logged out');
        }
        if (!empty($_COOKIE['remember_token'])) {
            Database::getInstance()->execute(
                'DELETE FROM remember_tokens WHERE token_hash = :h',
                ['h' => hash('sha256', $_COOKIE['remember_token'])]
            );
            setcookie('remember_token', '', time() - 3600, '/', '', true, true);
        }
        $_SESSION = [];
        session_unset();
        session_destroy();
    }

    private static function issueRememberToken(string $userId): void
    {
        $token = Security::generateToken();
        Database::getInstance()->insert(
            'INSERT INTO remember_tokens (user_id, token_hash, expires_at, created_at)
             VALUES (:uid, :hash, DATE_ADD(NOW(), INTERVAL 30 DAY), NOW())',
            ['uid' => $userId, 'hash' => hash('sha256', $token)]
        );
        setcookie('remember_token', $token, [
            'expires'  => time() + (30 * 86400),
            'path'     => '/',
            'secure'   => true,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    public static function verifyEmail(string $token): bool
    {
        $db   = Database::getInstance();
        $user = $db->fetchOne('SELECT id FROM users WHERE verify_token = :t LIMIT 1', ['t' => $token]);
        if (!$user) {
            return false;
        }
        $db->execute(
            'UPDATE users SET email_verified = 1, verify_token = NULL WHERE id = :id',
            ['id' => $user['id']]
        );
        AuditLog::record((string) $user['id'], 'account.verify_email', 'Email verified');
        return true;
    }

    /** Issue a password reset token and email it. Always returns true (no user enumeration). */
    public static function requestPasswordReset(string $email): bool
    {
        $email = strtolower(trim($email));
        $db    = Database::getInstance();
        $user  = $db->fetchOne('SELECT id, username FROM users WHERE email = :e LIMIT 1', ['e' => $email]);

        if ($user) {
            $token = Security::generateToken();
            $db->execute(
                'INSERT INTO password_resets (user_id, token_hash, expires_at, created_at)
                 VALUES (:uid, :hash, DATE_ADD(NOW(), INTERVAL 1 HOUR), NOW())',
                ['uid' => $user['id'], 'hash' => hash('sha256', $token)]
            );
            Mailer::sendPasswordResetEmail($email, $user['username'], $token);
            AuditLog::record((string) $user['id'], 'account.password_reset_requested', 'Password reset requested');
        }
        return true;
    }

    /** @return array{success: bool, error?: string} */
    public static function resetPassword(string $token, string $password, string $confirm): array
    {
        if ($password !== $confirm) {
            return ['success' => false, 'error' => 'Password confirmation does not match.'];
        }
        $violations = Security::passwordViolations($password);
        if (!empty($violations)) {
            return ['success' => false, 'error' => implode(' ', $violations)];
        }

        $db  = Database::getInstance();
        $row = $db->fetchOne(
            'SELECT id, user_id FROM password_resets
             WHERE token_hash = :h AND expires_at > NOW() AND used_at IS NULL
             ORDER BY id DESC LIMIT 1',
            ['h' => hash('sha256', $token)]
        );
        if (!$row) {
            return ['success' => false, 'error' => 'This reset link is invalid or has expired.'];
        }

        $db->execute('UPDATE users SET password_hash = :h WHERE id = :id', [
            'h'  => Security::hashPassword($password),
            'id' => $row['user_id'],
        ]);
        $db->execute('UPDATE password_resets SET used_at = NOW() WHERE id = :id', ['id' => $row['id']]);

        AuditLog::record((string) $row['user_id'], 'account.password_reset', 'Password reset completed');
        return ['success' => true];
    }
}
