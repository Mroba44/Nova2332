<?php
/**
 * footer.php
 *
 * Shared site footer + closing script tags. Include at the end of
 * every public-facing page, after the page's main content.
 */
declare(strict_types=1);
?>
<footer>
  <div class="container">
    <div class="footer-grid">
      <div class="footer-col">
        <h4 style="color:var(--white);font-family:var(--font-display);font-size:18px;letter-spacing:-0.01em;">Nova Global RP</h4>
        <p style="font-size:14px;max-width:280px;">A standard SA-MP roleplay server built around a persistent economy, custom factions, and a city that keeps running whether you're logged in or not.</p>
        <div class="social-row" style="margin-top:18px;">
          <a href="<?= e(DISCORD_INVITE_URL) ?>" target="_blank" rel="noopener" aria-label="Discord"><i class="fa-brands fa-discord"></i></a>
          <a href="#" aria-label="X / Twitter"><i class="fa-brands fa-x-twitter"></i></a>
          <a href="#" aria-label="YouTube"><i class="fa-brands fa-youtube"></i></a>
        </div>
      </div>
      <div class="footer-col">
        <h4>Server</h4>
        <ul>
          <li><a href="<?= url('/#features') ?>">Features</a></li>
          <li><a href="<?= url('/#news') ?>">News</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Community</h4>
        <ul>
          <li><a href="<?= e(DISCORD_INVITE_URL) ?>" target="_blank" rel="noopener">Discord</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Account</h4>
        <ul>
          <li><a href="<?= url('/login.php') ?>">Log in</a></li>
          <li><a href="<?= url('/register.php') ?>">Create account</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?= date('Y') ?> Nova Global RP. Not affiliated with Rockstar Games or Take-Two Interactive.</span>
      <span><?= APP_ENV === 'production' ? '' : 'ENV: ' . e(APP_ENV) ?></span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.10.5/sweetalert2.all.min.js"></script>
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
<script src="<?= url('assets/js/main.js') ?>"></script>
<?= $extraScripts ?? '' ?>
</body>
</html>
