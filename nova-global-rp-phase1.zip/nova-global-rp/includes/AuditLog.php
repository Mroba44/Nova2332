<?php
/**
 * AuditLog.php
 *
 * Writes an immutable trail of security-relevant events (logins,
 * registrations, password changes, and — from Phase 3 onward —
 * admin actions) to the `audit_logs` table.
 *
 * @package NovaGlobalRP
 */

declare(strict_types=1);

final class AuditLog
{
    public static function record(?string $userId, string $action, string $description = ''): void
    {
        try {
            Database::getInstance()->insert(
                'INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent, created_at)
                 VALUES (:uid, :action, :description, :ip, :ua, NOW())',
                [
                    'uid'         => $userId,
                    'action'      => $action,
                    'description' => $description,
                    'ip'          => Security::clientIp(),
                    'ua'          => substr($_SERVER['HTTP_USER_AGENT'] ?? 'unknown', 0, 255),
                ]
            );
        } catch (\Throwable $e) {
            error_log('[AUDIT] Failed to write audit log: ' . $e->getMessage());
        }
    }
}
