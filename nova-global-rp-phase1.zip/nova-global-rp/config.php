<?php
/**
 * config.php
 *
 * Central application bootstrap. Loads environment variables from .env,
 * defines global constants, configures PHP runtime security settings,
 * and starts a hardened session. This file is included by every
 * public-facing entry point as the very first statement.
 *
 * @package NovaGlobalRP
 */

declare(strict_types=1);

// ------------------------------------------------------------------
// Error handling — never leak stack traces / paths in production.
// ------------------------------------------------------------------
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/logs/php-error.log');

// ------------------------------------------------------------------
// Load .env into $_ENV / getenv()
// ------------------------------------------------------------------
function nova_load_env(string $path): void
{
    if (!is_file($path)) {
        // Fail closed: without config we cannot safely continue.
        http_response_code(500);
        error_log('[CONFIG] Missing .env file at ' . $path);
        exit('Server misconfiguration. Please try again later.');
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        if (!str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = explode('=', $line, 2);
        $key   = trim($key);
        $value = trim($value);
        // Strip matching surrounding quotes
        if ((str_starts_with($value, '"') && str_ends_with($value, '"')) ||
            (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
            $value = substr($value, 1, -1);
        }
        if (!array_key_exists($key, $_ENV)) {
            $_ENV[$key] = $value;
            putenv("{$key}={$value}");
        }
    }
}

$envFile = __DIR__ . '/.env';
if (!is_file($envFile) && is_file(__DIR__ . '/.env.example') && getenv('APP_ENV') === false) {
    // Local dev convenience only: never happens if a real .env exists.
    // Production deployments MUST provide a real .env file.
}
nova_load_env($envFile);

/**
 * Typed environment getter with default fallback.
 */
function env(string $key, mixed $default = null): mixed
{
    $value = $_ENV[$key] ?? getenv($key);
    if ($value === false || $value === null) {
        return $default;
    }
    return match (strtolower((string) $value)) {
        'true', '(true)'   => true,
        'false', '(false)' => false,
        'null', '(null)'   => null,
        default             => $value,
    };
}

// ------------------------------------------------------------------
// Global constants
// ------------------------------------------------------------------
define('APP_NAME', env('APP_NAME', 'Nova Global RP'));
define('APP_ENV', env('APP_ENV', 'production'));
define('APP_DEBUG', (bool) env('APP_DEBUG', false));
define('APP_URL', rtrim((string) env('APP_URL', 'https://localhost'), '/'));
define('APP_TIMEZONE', env('APP_TIMEZONE', 'UTC'));
define('APP_KEY', env('APP_KEY'));
define('PASSWORD_PEPPER', env('PASSWORD_PEPPER', ''));
define('CSRF_TOKEN_NAME', env('CSRF_TOKEN_NAME', 'nova_csrf_token'));
define('SESSION_LIFETIME_MIN', (int) env('SESSION_LIFETIME', 120));

define('DB_HOST', env('DB_HOST', '127.0.0.1'));
define('DB_PORT', env('DB_PORT', '3306'));
define('DB_DATABASE', env('DB_DATABASE', 'nova_global_rp'));
define('DB_USERNAME', env('DB_USERNAME', 'root'));
define('DB_PASSWORD', env('DB_PASSWORD', ''));
define('DB_CHARSET', env('DB_CHARSET', 'utf8mb4'));

define('SAMP_SERVER_IP', env('SAMP_SERVER_IP', '127.0.0.1'));
define('SAMP_SERVER_PORT', (int) env('SAMP_SERVER_PORT', 7777));
define('SAMP_QUERY_TIMEOUT', (int) env('SAMP_QUERY_TIMEOUT', 2));

define('RECAPTCHA_SITE_KEY', env('RECAPTCHA_SITE_KEY', ''));
define('RECAPTCHA_SECRET_KEY', env('RECAPTCHA_SECRET_KEY', ''));

define('DISCORD_INVITE_URL', env('DISCORD_INVITE_URL', '#'));
define('DISCORD_WEBHOOK_URL', env('DISCORD_WEBHOOK_URL', ''));

define('MAIL_HOST', env('MAIL_HOST'));
define('MAIL_PORT', (int) env('MAIL_PORT', 587));
define('MAIL_USERNAME', env('MAIL_USERNAME'));
define('MAIL_PASSWORD', env('MAIL_PASSWORD'));
define('MAIL_ENCRYPTION', env('MAIL_ENCRYPTION', 'tls'));
define('MAIL_FROM_ADDRESS', env('MAIL_FROM_ADDRESS', 'noreply@localhost'));
define('MAIL_FROM_NAME', env('MAIL_FROM_NAME', APP_NAME));

date_default_timezone_set(APP_TIMEZONE);

if (APP_KEY === null || APP_KEY === 'change_this_to_a_random_64_char_hex_string') {
    error_log('[CONFIG] APP_KEY is not set to a secure value. Generate one before going to production.');
}

// ------------------------------------------------------------------
// Hardened session configuration (must run before session_start()).
// ------------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

    session_name('nova_session');
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME_MIN * 60,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', (string) (SESSION_LIFETIME_MIN * 60));
    session_start();

    // Session fixation guard + idle timeout.
    if (!isset($_SESSION['_created'])) {
        $_SESSION['_created'] = time();
    } elseif (time() - $_SESSION['_created'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['_created'] = time();
    }

    if (isset($_SESSION['_last_activity']) &&
        (time() - $_SESSION['_last_activity']) > (SESSION_LIFETIME_MIN * 60)) {
        $_SESSION = [];
        session_unset();
        session_destroy();
        session_start();
    }
    $_SESSION['_last_activity'] = time();
}

// ------------------------------------------------------------------
// Security headers — applied to every response.
// ------------------------------------------------------------------
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
header(
    "Content-Security-Policy: default-src 'self'; " .
    "script-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://www.google.com https://www.gstatic.com 'unsafe-inline'; " .
    "style-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://fonts.googleapis.com 'unsafe-inline'; " .
    "font-src 'self' https://cdnjs.cloudflare.com https://fonts.gstatic.com; " .
    "img-src 'self' data:; " .
    "connect-src 'self'; " .
    "frame-src https://www.google.com;"
);
if (($isHttps ?? false)) {
    header('Strict-Transport-Security: max-age=63072000; includeSubDomains; preload');
}

// ------------------------------------------------------------------
// Autoload core classes (no Composer dependency for the core app).
// ------------------------------------------------------------------
spl_autoload_register(function (string $class): void {
    $path = __DIR__ . '/includes/' . $class . '.php';
    if (is_file($path)) {
        require_once $path;
    }
});

require_once __DIR__ . '/includes/functions.php';
