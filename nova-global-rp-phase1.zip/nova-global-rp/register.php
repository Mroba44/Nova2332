<?php
/**
 * register.php
 */
declare(strict_types=1);
require_once __DIR__ . '/config.php';

if (Auth::isLoggedIn()) {
    redirect('/ucp/');
}

$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
$errors = [];
$old    = ['username' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::requireCsrf();

    $username = (string) ($_POST['username'] ?? '');
    $email    = (string) ($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $confirm  = (string) ($_POST['confirm_password'] ?? '');
    $old      = ['username' => $username, 'email' => $email];

    if (empty($_POST['terms'])) {
        $errors[] = 'You must accept the server rules and terms to register.';
    }

    if (!Security::rateLimit('register_' . Security::clientIp(), 5, 600)) {
        $errors[] = 'Too many registration attempts from this connection. Please try again later.';
    } elseif (empty($errors)) {
        $result = Auth::register($username, $email, $password, $confirm);
        if ($result['success']) {
            $msg = 'Account created. Check your email for a verification link before logging in.';
            if ($isAjax) {
                jsonResponse(['success' => true, 'title' => 'Account created', 'message' => $msg, 'redirect' => url('/login.php')]);
            }
            flash('success', $msg);
            redirect('/login.php');
        }
        $errors = $result['errors'];
    }

    if ($isAjax) {
        jsonResponse(['success' => false, 'errors' => $errors], 422);
    }
}

$pageTitle = 'Create Account — ' . APP_NAME;
$extraHead = '<link rel="stylesheet" href="' . url('assets/css/auth.css') . '">';
require __DIR__ . '/includes/header.php';
?>

<div class="auth-shell">
  <div class="auth-visual">
    <div class="quote">
      <p>"We don't hand out whitelists. We hand out consequences."</p>
      <span>— Nova Global RP, Onboarding Notice</span>
    </div>
  </div>

  <div class="auth-form-wrap">
    <div class="auth-card">
      <h1>Create your account</h1>
      <p class="lead">This is your website account — you'll create in-game characters after logging in.</p>

      <?php if (!empty($errors)): ?>
        <div class="form-error">
          <ul><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <form method="post" action="<?= url('/register.php') ?>" data-ajax novalidate>
        <?= Security::csrfField() ?>
        <div class="field">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" value="<?= e($old['username']) ?>" placeholder="John_Doe" autocomplete="username" required>
          <div class="field-hint">3-24 characters, SA-MP name format (e.g. John_Doe).</div>
        </div>
        <div class="field">
          <label for="email">Email address</label>
          <input type="email" id="email" name="email" value="<?= e($old['email']) ?>" autocomplete="email" required>
        </div>
        <div class="field">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" autocomplete="new-password" required>
          <div class="field-hint">At least 8 characters, with uppercase, lowercase, and a number.</div>
        </div>
        <div class="field">
          <label for="confirm_password">Confirm password</label>
          <input type="password" id="confirm_password" name="confirm_password" autocomplete="new-password" required>
        </div>
        <div class="field-row">
          <label class="checkbox-row"><input type="checkbox" name="terms" value="1" required> I agree to the server rules and terms.</label>
        </div>
        <button type="submit" class="btn btn-primary btn-block btn-lg">Create account</button>
      </form>

      <p class="auth-switch">Already have an account? <a href="<?= url('/login.php') ?>">Log in</a></p>
    </div>
  </div>
</div>

<?php
$extraScripts = '<script src="' . url('assets/js/auth.js') . '"></script>';
require __DIR__ . '/includes/footer.php';
?>
