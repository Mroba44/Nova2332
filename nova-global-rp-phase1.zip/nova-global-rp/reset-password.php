<?php
/**
 * reset-password.php
 */
declare(strict_types=1);
require_once __DIR__ . '/config.php';

$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
$token  = Security::clean($_GET['token'] ?? $_POST['token'] ?? '');
$errors = [];

if ($token === '') {
    flash('error', 'Missing or invalid reset link.');
    redirect('/forgot-password.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::requireCsrf();
    $password = (string) ($_POST['password'] ?? '');
    $confirm  = (string) ($_POST['confirm_password'] ?? '');

    $result = Auth::resetPassword($token, $password, $confirm);
    if ($result['success']) {
        $msg = 'Password updated. You can now log in.';
        if ($isAjax) {
            jsonResponse(['success' => true, 'title' => 'Password updated', 'message' => $msg, 'redirect' => url('/login.php')]);
        }
        flash('success', $msg);
        redirect('/login.php');
    }
    $errors[] = $result['error'];

    if ($isAjax) {
        jsonResponse(['success' => false, 'errors' => $errors], 422);
    }
}

$pageTitle = 'Reset Password — ' . APP_NAME;
$extraHead = '<link rel="stylesheet" href="' . url('assets/css/auth.css') . '">';
require __DIR__ . '/includes/header.php';
?>

<div class="auth-shell">
  <div class="auth-visual">
    <div class="quote">
      <p>"Choose a stronger one this time."</p>
      <span>— Nova Global RP, Account Recovery</span>
    </div>
  </div>

  <div class="auth-form-wrap">
    <div class="auth-card">
      <h1>Set a new password</h1>
      <p class="lead">Make it at least 8 characters, with a mix of upper, lower, and a number.</p>

      <?php if (!empty($errors)): ?>
        <div class="form-error">
          <ul><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <form method="post" action="<?= url('/reset-password.php') ?>" data-ajax novalidate>
        <?= Security::csrfField() ?>
        <input type="hidden" name="token" value="<?= e($token) ?>">
        <div class="field">
          <label for="password">New password</label>
          <input type="password" id="password" name="password" autocomplete="new-password" required>
        </div>
        <div class="field">
          <label for="confirm_password">Confirm new password</label>
          <input type="password" id="confirm_password" name="confirm_password" autocomplete="new-password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block btn-lg">Update password</button>
      </form>
    </div>
  </div>
</div>

<?php
$extraScripts = '<script src="' . url('assets/js/auth.js') . '"></script>';
require __DIR__ . '/includes/footer.php';
?>
