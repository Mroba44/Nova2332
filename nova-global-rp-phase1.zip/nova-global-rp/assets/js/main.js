/**
 * main.js
 * Site-wide behaviour: mobile nav drawer, flash message lifecycle,
 * one orchestrated hero entrance (GSAP), scroll reveals (AOS), and
 * live SA-MP status polling for the HUD panel.
 */
(function () {
  'use strict';

  // ---------- Mobile nav ----------
  const navToggle = document.getElementById('navToggle');
  const drawer = document.getElementById('mobileDrawer');
  if (navToggle && drawer) {
    navToggle.addEventListener('click', () => {
      const isOpen = drawer.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
      navToggle.innerHTML = isOpen
        ? '<i class="fa-solid fa-xmark"></i>'
        : '<i class="fa-solid fa-bars"></i>';
    });
  }

  // ---------- Flash messages ----------
  const flashStack = document.getElementById('flashStack');
  if (flashStack) {
    Array.from(flashStack.children).forEach((el, i) => {
      setTimeout(() => {
        el.style.transition = 'opacity .4s ease, transform .4s ease';
        el.style.opacity = '0';
        el.style.transform = 'translateX(20px)';
        setTimeout(() => el.remove(), 400);
      }, 5000 + i * 300);
    });
  }

  // ---------- AOS scroll reveals ----------
  if (window.AOS) {
    AOS.init({ duration: 600, once: true, offset: 60, easing: 'ease-out-quad' });
  }

  // ---------- One orchestrated hero entrance ----------
  if (window.gsap && document.querySelector('.hero')) {
    const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });
    tl.from('.hero-kicker', { opacity: 0, y: 12, duration: .5 })
      .from('.hero h1', { opacity: 0, y: 18, duration: .6 }, '-=.3')
      .from('.hero-sub', { opacity: 0, y: 14, duration: .5 }, '-=.35')
      .from('.hero-actions .btn', { opacity: 0, y: 10, duration: .45, stagger: .1 }, '-=.3')
      .from('.hero-meta > div', { opacity: 0, y: 10, duration: .4, stagger: .08 }, '-=.25')
      .from('.hud-panel', { opacity: 0, x: 24, duration: .6 }, '-=.6');
  }

  // ---------- Live server status polling ----------
  const hud = document.getElementById('serverHud');
  if (hud) {
    const render = (data) => {
      const pill = hud.querySelector('[data-hud="pill"]');
      const players = hud.querySelector('[data-hud="players"]');
      const maxPlayers = hud.querySelector('[data-hud="maxplayers"]');
      const ping = hud.querySelector('[data-hud="ping"]');
      const barFill = hud.querySelector('[data-hud="barfill"]');
      const name = hud.querySelector('[data-hud="hostname"]');

      if (data.online) {
        pill.className = 'status-pill online';
        pill.innerHTML = '<span class="dot"></span> Online';
        players.textContent = data.players ?? 0;
        maxPlayers.textContent = '/ ' + (data.max_players ?? 0);
        ping.textContent = (data.ping ?? '--') + ' ms';
        if (name && data.hostname) name.textContent = data.hostname;
        const pct = data.max_players ? Math.min(100, (data.players / data.max_players) * 100) : 0;
        if (barFill) barFill.style.width = pct + '%';
      } else {
        pill.className = 'status-pill offline';
        pill.innerHTML = '<span class="dot"></span> Offline';
        players.textContent = '0';
        maxPlayers.textContent = '/ --';
        ping.textContent = '-- ms';
        if (barFill) barFill.style.width = '0%';
      }
    };

    const poll = () => {
      fetch('/api/status.php', { headers: { Accept: 'application/json' } })
        .then((r) => r.json())
        .then(render)
        .catch(() => {});
    };

    poll();
    setInterval(poll, 15000);
  }
})();
