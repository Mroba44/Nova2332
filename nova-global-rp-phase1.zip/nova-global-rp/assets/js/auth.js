/**
 * auth.js
 * Progressive-enhancement AJAX submission for the login/register/
 * forgot-password/reset-password forms, with SweetAlert2 feedback.
 * Every form still works with plain POST + a full page reload if
 * JS is disabled — this only makes it feel instant when it's on.
 */
(function () {
  'use strict';

  function submitForm(form, endpoint) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('[type="submit"]');
    const originalLabel = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Please wait…';
    }

    fetch(endpoint, {
      method: 'POST',
      body: formData,
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.success) {
          if (window.Swal) {
            Swal.fire({
              title: data.title || 'Success',
              text: data.message || '',
              icon: 'success',
              background: '#0b1220',
              color: '#eef2fb',
              confirmButtonColor: '#2f6bff',
            }).then(() => {
              if (data.redirect) window.location.href = data.redirect;
            });
          } else if (data.redirect) {
            window.location.href = data.redirect;
          }
        } else {
          const list = Array.isArray(data.errors) ? data.errors : [data.error || 'Something went wrong.'];
          if (window.Swal) {
            Swal.fire({
              title: 'Please check the form',
              html: list.map((m) => `<div>${m}</div>`).join(''),
              icon: 'error',
              background: '#0b1220',
              color: '#eef2fb',
              confirmButtonColor: '#2f6bff',
            });
          } else {
            alert(list.join('\n'));
          }
        }
      })
      .catch(() => {
        if (window.Swal) {
          Swal.fire({
            title: 'Network error',
            text: 'Could not reach the server. Please try again.',
            icon: 'error',
            background: '#0b1220',
            color: '#eef2fb',
          });
        }
      })
      .finally(() => {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalLabel;
        }
      });
  }

  document.querySelectorAll('form[data-ajax]').forEach((form) => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      submitForm(form, form.getAttribute('action') || window.location.href);
    });
  });
})();
