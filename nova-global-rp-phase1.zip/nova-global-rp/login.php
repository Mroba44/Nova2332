<?php
/**
 * login.php
 */
declare(strict_types=1);
require_once __DIR__ . '/config.php';

if (Auth::isLoggedIn()) {
    redirect('/ucp/');
}

$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::requireCsrf();

    $identifier = Security::clean($_POST['identifier'] ?? '');
    $password   = (string) ($_POST['password'] ?? '');
    $remember   = !empty($_POST['remember']);

    if ($identifier === '' || $password === '') {
        $errors[] = 'Please enter your username/email and password.';
    } else {
        $result = Auth::login($identifier, $password, $remember);
        if ($result['success']) {
            if ($isAjax) {
                jsonResponse(['success' => true, 'title' => 'Welcome back', 'redirect' => url('/ucp/')]);
            }
            redirect('/ucp/');
        }
        $errors[] = $result['error'];
    }

    if ($isAjax) {
        jsonResponse(['success' => false, 'errors' => $errors], 422);
    }
}

$pageTitle = 'Log In — ' . APP_NAME;
$extraHead = '<link rel="stylesheet" href="' . url('assets/css/auth.css') . '">';
require __DIR__ . '/includes/header.php';
?>

<div class="auth-shell">
  <div class="auth-visual">
    <div class="quote">
      <p>"Nobody remembers your spawn point. They remember what you built after it."</p>
      <span>— Nova Global RP, City Charter</span>
    </div>
  </div>

  <div class="auth-form-wrap">
    <div class="auth-card">
      <h1>Welcome back</h1>
      <p class="lead">Log in to manage your characters, houses, and businesses.</p>

      <?php if (!empty($errors)): ?>
        <div class="form-error">
          <ul><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <form method="post" action="<?= url('/login.php') ?>" data-ajax novalidate>
        <?= Security::csrfField() ?>
        <div class="field">
          <label for="identifier">Username or email</label>
          <input type="text" id="identifier" name="identifier" autocomplete="username" required>
        </div>
        <div class="field">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" autocomplete="current-password" required>
        </div>
        <div class="field-row">
          <label class="checkbox-row"><input type="checkbox" name="remember" value="1"> Remember me</label>
          <a href="<?= url('/forgot-password.php') ?>">Forgot password?</a>
        </div>
        <button type="submit" class="btn btn-primary btn-block btn-lg">Log in</button>
      </form>

      <p class="auth-switch">Don't have an account? <a href="<?= url('/register.php') ?>">Create one</a></p>
    </div>
  </div>
</div>

<?php
$extraScripts = '<script src="' . url('assets/js/auth.js') . '"></script>';
require __DIR__ . '/includes/footer.php';
?>
