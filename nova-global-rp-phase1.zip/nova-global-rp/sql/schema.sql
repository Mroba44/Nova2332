-- ============================================================
-- Nova Global RP — Database Schema (Phase 1)
-- Engine: InnoDB | Charset: utf8mb4 / utf8mb4_unicode_ci
--
-- Covers: accounts, authentication security, and the news feed
-- shown on the homepage. Later phases (UCP, admin, store, API)
-- extend this file with additional tables — this file is safe
-- to run first on a fresh database.
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- users
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id`               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`         VARCHAR(24)     NOT NULL,
  `email`            VARCHAR(191)    NOT NULL,
  `password_hash`    VARCHAR(255)    NOT NULL,
  `role`             ENUM('player','helper','moderator','administrator','developer','owner') NOT NULL DEFAULT 'player',
  `status`           ENUM('active','suspended','banned') NOT NULL DEFAULT 'active',
  `email_verified`   TINYINT(1)      NOT NULL DEFAULT 0,
  `verify_token`     VARCHAR(64)     NULL,
  `avatar`           VARCHAR(255)    NULL,
  `two_factor_secret` VARCHAR(64)    NULL,
  `last_login_at`    DATETIME        NULL,
  `last_login_ip`    VARCHAR(45)     NULL,
  `created_at`       DATETIME        NOT NULL,
  `updated_at`       DATETIME        NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- user_wallets  (created alongside every user; expanded in Phase 2)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `user_wallets` (
  `user_id`    BIGINT UNSIGNED NOT NULL,
  `cash`       BIGINT NOT NULL DEFAULT 0,
  `bank`       BIGINT NOT NULL DEFAULT 0,
  `coins`      BIGINT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_wallets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- login_attempts  (brute-force auditing, keyed by identifier + IP)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `identifier`   VARCHAR(191) NOT NULL,
  `ip_address`   VARCHAR(45)  NOT NULL,
  `success`      TINYINT(1)   NOT NULL,
  `user_agent`   VARCHAR(255) NULL,
  `created_at`   DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_attempts_lookup` (`identifier`, `ip_address`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- login_history  (successful logins, shown to the user in UCP later)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `login_history` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    BIGINT UNSIGNED NOT NULL,
  `ip_address` VARCHAR(45)  NOT NULL,
  `user_agent` VARCHAR(255) NULL,
  `created_at` DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_login_history_user` (`user_id`, `created_at`),
  CONSTRAINT `fk_login_history_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- remember_tokens  ("remember me" persistent login)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `remember_tokens` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    BIGINT UNSIGNED NOT NULL,
  `token_hash` CHAR(64)  NOT NULL,
  `expires_at` DATETIME  NOT NULL,
  `created_at` DATETIME  NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_remember_token_hash` (`token_hash`),
  KEY `idx_remember_user` (`user_id`),
  CONSTRAINT `fk_remember_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- password_resets
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `password_resets` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    BIGINT UNSIGNED NOT NULL,
  `token_hash` CHAR(64)  NOT NULL,
  `expires_at` DATETIME  NOT NULL,
  `used_at`    DATETIME  NULL,
  `created_at` DATETIME  NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reset_token_hash` (`token_hash`),
  KEY `idx_reset_user` (`user_id`),
  CONSTRAINT `fk_reset_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- audit_logs  (security-relevant events; admin actions from Phase 3 on)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     BIGINT UNSIGNED NULL,
  `action`      VARCHAR(64)  NOT NULL,
  `description` VARCHAR(500) NULL,
  `ip_address`  VARCHAR(45)  NOT NULL,
  `user_agent`  VARCHAR(255) NULL,
  `created_at`  DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`, `created_at`),
  KEY `idx_audit_action` (`action`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- news  (homepage feed + /news.php in Phase 4)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `news` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `author_id`     BIGINT UNSIGNED NULL,
  `title`         VARCHAR(180) NOT NULL,
  `slug`          VARCHAR(200) NOT NULL,
  `excerpt`       VARCHAR(300) NULL,
  `body`          MEDIUMTEXT   NOT NULL,
  `category`      VARCHAR(40)  NOT NULL DEFAULT 'Announcement',
  `status`        ENUM('draft','published') NOT NULL DEFAULT 'draft',
  `published_at`  DATETIME     NULL,
  `created_at`    DATETIME     NOT NULL,
  `updated_at`    DATETIME     NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_news_slug` (`slug`),
  KEY `idx_news_status_pub` (`status`, `published_at`),
  CONSTRAINT `fk_news_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- site_settings  (key/value store used across admin panel, Phase 3+)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `site_settings` (
  `setting_key`   VARCHAR(100) NOT NULL,
  `setting_value` TEXT NULL,
  `updated_at`    DATETIME NOT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Default seed data
-- ------------------------------------------------------------
INSERT INTO `site_settings` (`setting_key`, `setting_value`, `updated_at`) VALUES
  ('maintenance_mode', '0', NOW()),
  ('site_name', 'Nova Global RP', NOW())
ON DUPLICATE KEY UPDATE `setting_key` = `setting_key`;

INSERT INTO `news` (`author_id`, `title`, `slug`, `excerpt`, `body`, `category`, `status`, `published_at`, `created_at`, `updated_at`)
VALUES (
  NULL,
  'Nova Global RP is live',
  'nova-global-rp-is-live',
  'The server just launched — check back here for patch notes and event announcements.',
  '<p>Welcome to Nova Global RP. This post will be replaced by the admin team''s first real update.</p>',
  'Announcement',
  'published',
  NOW(),
  NOW(),
  NOW()
) ON DUPLICATE KEY UPDATE `slug` = `slug`;

SET FOREIGN_KEY_CHECKS = 1;
