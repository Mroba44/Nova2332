# Nova Global RP — Website (Phase 1)

Website, UCP, admin panel, and API for the **Nova Global RP** SA-MP roleplay server.

This delivery covers **Phase 1** of the build: project skeleton, configuration,
database, authentication, security baseline, homepage, navigation, and the
live SA-MP server status widget. Later phases (UCP, admin panel, public
pages, store, REST API) extend this same codebase — see `ROADMAP` notes in
each phase's delivery message.

## Requirements

- PHP 8.1+ with `pdo_mysql`, `mbstring`, `openssl` extensions
- MySQL 5.7+ / MariaDB 10.3+
- Apache with `mod_rewrite` and `mod_headers` (or Nginx equivalent — see below)
- Composer (for PHPMailer; the app runs without it but emails fall back to `mail()`)

## Setup

1. Upload everything to your web root via FTP or File Manager.
2. Copy `.env.example` to `.env` and fill in real values:
   ```
   cp .env.example .env
   ```
   Generate a secure `APP_KEY` and `PASSWORD_PEPPER`:
   ```
   php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
   ```
3. Create the database and import the schema:
   ```
   mysql -u youruser -p your_database < sql/schema.sql
   ```
4. Install PHP dependencies (optional but recommended, for real SMTP email):
   ```
   composer install
   ```
5. Point your `SAMP_SERVER_IP` / `SAMP_SERVER_PORT` in `.env` at your actual
   game server — the homepage queries it live over the SA-MP UDP query
   protocol (no third-party API).
6. Make sure `logs/`, `cache/`, `storage/`, and `uploads/` are writable by
   the PHP process (`chmod 755` is sufficient on most shared hosts).
7. Visit the site. Register an account, verify the email link (check
   `logs/php-error.log` for the link if SMTP isn't configured yet — the
   fallback mailer will still attempt native `mail()`).

## Nginx note

This project ships an Apache `.htaccess`. If you're on Nginx, replicate the
same rules (deny dotfiles, deny `/includes /logs /cache /storage /sql /vendor`,
disable PHP execution in `/uploads`) in your server block — `.htaccess` files
are ignored by Nginx.

## Security notes

- All queries use PDO prepared statements (see `includes/Database.php`).
- CSRF tokens are required on every state-changing POST (`Security::requireCsrf()`).
- Passwords are hashed with bcrypt + a server-side pepper.
- Sessions are hardened (HttpOnly, SameSite=Lax, Secure when served over HTTPS,
  regenerated on login, idle-timeout enforced).
- Login attempts are rate-limited per IP and per identifier.
- Security headers (CSP, X-Frame-Options, etc.) are set in `config.php`.

## Project structure (Phase 1)

```
/config.php              Bootstrap: env loading, sessions, security headers
/.env.example             Environment template
/index.php                Homepage
/login.php, register.php, forgot-password.php, reset-password.php, verify-email.php
/includes/                Database.php, Auth.php, Security.php, AuditLog.php,
                           SampQuery.php, Mailer.php, functions.php, header.php, footer.php
/assets/css/               style.css (site), auth.css (auth pages)
/assets/js/                 main.js (nav, HUD polling), auth.js (AJAX forms)
/api/status.php            Public JSON endpoint powering the live status HUD
/sql/schema.sql             Phase 1 database schema
/admin/ /ucp/ /api/         Reserved — populated in Phases 2, 3, 6
/uploads/ /storage/ /cache/ /logs/ /cron/ /vendor/   Reserved / runtime directories
```
