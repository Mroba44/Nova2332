<?php
/**
 * verify-email.php
 */
declare(strict_types=1);
require_once __DIR__ . '/config.php';

$token   = Security::clean($_GET['token'] ?? '');
$success = $token !== '' && Auth::verifyEmail($token);

$pageTitle = 'Verify Email — ' . APP_NAME;
require __DIR__ . '/includes/header.php';
?>

<section class="section container" style="text-align:center;max-width:520px;margin:0 auto;">
  <?php if ($success): ?>
    <div class="hud-panel" style="text-align:left;">
      <div class="icon" style="color:var(--success);font-size:32px;margin-bottom:16px;"><i class="fa-solid fa-circle-check"></i></div>
      <h2 style="color:var(--white);">Email verified</h2>
      <p>Your account is active. You can log in now.</p>
      <a href="<?= url('/login.php') ?>" class="btn btn-primary" style="margin-top:12px;">Log in</a>
    </div>
  <?php else: ?>
    <div class="hud-panel" style="text-align:left;">
      <div class="icon" style="color:var(--danger);font-size:32px;margin-bottom:16px;"><i class="fa-solid fa-circle-exclamation"></i></div>
      <h2 style="color:var(--white);">Verification link invalid</h2>
      <p>This link has already been used or has expired. Try logging in — if your email still isn't verified, request a new link by registering again.</p>
      <a href="<?= url('/login.php') ?>" class="btn btn-outline" style="margin-top:12px;">Back to log in</a>
    </div>
  <?php endif; ?>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
