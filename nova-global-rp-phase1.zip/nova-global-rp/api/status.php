<?php
/**
 * api/status.php
 *
 * Lightweight, unauthenticated JSON endpoint that exposes the live
 * SA-MP server status for the homepage HUD panel to poll via fetch().
 * Read-only, cached at the SampQuery layer, and rate-limited per IP
 * to prevent abuse.
 *
 * @package NovaGlobalRP
 */

declare(strict_types=1);
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json; charset=utf-8');

if (!Security::rateLimit('api_status_' . Security::clientIp(), 30, 60)) {
    jsonResponse(['error' => 'Too many requests.'], 429);
}

$status = SampQuery::getStatus();
jsonResponse($status);
